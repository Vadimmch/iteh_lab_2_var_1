<?php
require 'connection.php';
require 'inc/groups.php';
require 'inc/teachers.php';
require 'inc/auditoriums.php';


?>
<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Первый Вариант</title>


    <script src="assets/vendors/jquery-3.5.0.min.js"></script>
    
    <script src="assets/js/common.js"></script>
    <style>tr,td,th{padding: 10px;}</style>
</head>
<body>
    <section class="container">
        
        <!-- Первое задание -->
        <h2>Лабораторные работы выбранной группы</h2>
        <form id="form1" action="forms/lessons-by-group.php" class="form-group">
            <select name="group">
                <?php
                    foreach ($groups as $group){
                        echo '<option value="'.$group.'">'.$group.'</option>';
                    }
                ?>
            </select>
            <input type="button" value="Отправить" onclick="getRes1(this)">
            <input type="button" value="Данные с LocalStorage" onclick="getLocal1(this)">
        </form>
        <!--   -->
        <table id="result1" class="table table-bordered table-sm">
            <thead>
                <tr>
                    <th>Дата</th>
                    <th>Номер пары</th>
                    <th>Аудитория</th>
                    <th>Дисциплина</th>
                    <th>Преподователи</th>
                </tr>
            </thead>
            <tbody>
                
            </tbody>
        </table>


        <!--  Второе задание  -->
       <h2>Лекции выбранного преподователя.</h2>
       <form id="form2" action="forms/lessons-by-teacher.php" class="form-group">
           <select name="teacher">
               <?php
                   foreach ($teachers as $teacher){
                       echo '<option value="'.$teacher.'">'.$teacher.'</option>';
                   }
               ?>
           </select>
           <input type="button" value="Отправить" onclick="getRes2(this)">
           <input type="button" value="Данные с LocalStorage" onclick="getLocal2(this)">
       </form>
       <table id="result2" class="table table-bordered table-sm">
            <thead>
                <tr>
                    <th>Дата</th>
                    <th>Номер пары</th>
                    <th>Аудитория</th>
                    <th>Дисциплина</th>
                    <th>Группы</th>
                </tr>
            </thead>
            <tbody>
                
            </tbody>
        </table>
       
       <!-- Третье задание -->

       <h2>Занятия в выбранной аудитории</h2>
       <form id="form3" action="forms/lessons-by-auditorium.php" class="form-group">
           <select name="auditorium">
               <?php
                   foreach ($auditoriums as $auditorium){
                       echo '<option value="'.$auditorium.'">'.$auditorium.'</option>';
                   }
               ?>
           </select>
           <input type="button" value="Отправить" onclick="getRes3(this)">
           <input type="button" value="Данные с LocalStorage" onclick="getLocal3(this)">
       </form>
       <table id="result3" class="table table-bordered table-sm">
            <thead>
                <tr>
                    <th>Дата</th>
                    <th>Номер пары</th>
                    <th>Аудитория</th>
                    <th>Дисциплина</th>
                    <th>Тип занятия</th>
                    <th>Группы</th>
                    <th>Преподователи</th>
                </tr>
            </thead>
            <tbody>
                
            </tbody>
        </table>
        <!--  -->
    </section>
</body>
</html>