<?php

require "../connection.php";

$cursor = $db->lessons->find([
	'auditorium'	=>	$_GET['auditorium']
	],[
		'projection' => ['_id'=>0]
	]);
$lessons = iterator_to_array($cursor);

foreach ($lessons as $key => $lesson) {
	$lesson['date'] =  $lesson['date']->toDateTime()->format('d.m.Y');
}

echo json_encode($lessons);