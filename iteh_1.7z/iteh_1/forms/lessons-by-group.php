<?php
require "../connection.php";

$cursor = $db->lessons->find([
	'groups'	=>	[
		'$in'=>[$_GET['group']]
	],
	'type' 		=>	'Laboratory'
	],[
		'projection' => ['_id'=>0,'type'=>0,'groups'=>0]
	]);
$lessons = iterator_to_array($cursor);

foreach ($lessons as $key => $lesson) {
	$lesson['date'] =  $lesson['date']->toDateTime()->format('d.m.Y');
}

echo json_encode($lessons);