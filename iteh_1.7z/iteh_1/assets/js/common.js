function getRes1(e){
	var currentForm = $(e).parents('form');

	$.ajax({
	  type: "GET",
	  url: "forms/lessons-by-group.php",
	  data: currentForm.serialize(),
	  dataType: 'json',
	  success: function(result){
	  	
	  	var output = "";
	  	
	  	for (var i = 0; i < result.length; i++) {
	  		output += '<tr>'+
	  			'<td>' + result[i].date + '</td>' +
	  			'<td>' + result[i].lesson_number + '</td>' +
	  			'<td>' + result[i].auditorium + '</td>' +
	  			'<td>' + result[i].disciple + '</td>'+
	  			'<td><ul>';
  			for (var j = 0; j < result[i].teacher.length; j++) {
  				output += '<li>' + result[i].teacher[j] + '</li>';
  			}
	  		output +='</ul></td></tr>';
	  	}
	  	$('#result1 tbody').html(output);
	  	localStorage.setItem('form1Result', JSON.stringify(result));
	  	localStorage.setItem('form1Data', currentForm.serialize());
	  }
	});
}

function getRes2(e){
	var currentForm = $(e).parents('form');

	$.ajax({
	  type: "GET",
	  url: "forms/lessons-by-teacher.php",
	  data: currentForm.serialize(),
	  dataType: 'json',
	  success: function(result){
  		var output = "";
	  	
	  	for (var i = 0; i < result.length; i++) {
	  		output += '<tr>'+
	  			'<td>' + result[i].date + '</td>' +
	  			'<td>' + result[i].lesson_number + '</td>' +
	  			'<td>' + result[i].auditorium + '</td>' +
	  			'<td>' + result[i].disciple + '</td>'+
	  			'<td><ul>';
  			for (var j = 0; j < result[i].groups.length; j++) {
  				output += '<li>' + result[i].groups[j] + '</li>';
  			}
	  		output +='</ul></td></tr>';
	  	}
	  	$('#result2 tbody').html(output);


  		localStorage.setItem('form2Result', JSON.stringify(result));
	  	localStorage.setItem('form2Data', currentForm.serialize());
	  }
	});
}

function getRes3(e){
	var currentForm = $(e).parents('form');

	$.ajax({
	  type: "GET",
	  url: "forms/lessons-by-auditorium.php",
	  data: currentForm.serialize(),
	  dataType: "json",
	  success: function(result){
  		var output = "";
	  	
	  	for (var i = 0; i < result.length; i++) {
	  		output += '<tr>'+
	  			'<td>' + result[i].date + '</td>' +
	  			'<td>' + result[i].lesson_number + '</td>' +
	  			'<td>' + result[i].auditorium + '</td>' +
	  			'<td>' + result[i].disciple + '</td>'+
	  			'<td>' + result[i].type + '</td>'+
	  			'<td><ul>';
  			for (var j = 0; j < result[i].groups.length; j++) {
  				output += '<li>' + result[i].groups[j] + '</li>';
  			}
  			output += '</ul></td><td><ul>';
  			for (var j = 0; j < result[i].teacher.length; j++) {
  				output += '<li>' + result[i].teacher[j] + '</li>';
  			}
	  		output +='</ul></td></tr>';
	  	}
	  	$('#result3 tbody').html(output);


	  	localStorage.setItem('form3Result', JSON.stringify(result));
	  	localStorage.setItem('form3Data', currentForm.serialize());
	  }
	});
}




// LOCAL STORAGE



function getLocal1(e) {
	$('#result1 tbody').html('');
	var currentForm = $(e).parents('form');
	var result = JSON.parse(localStorage.getItem('form1Result'));
	var data = localStorage.getItem('form1Data');
	if (currentForm.serialize() === data) {
	  	var output = "";

	  	for (var i = 0; i < result.length; i++) {
	  		output += '<tr>'+
	  			'<td>' + result[i].date + '</td>' +
	  			'<td>' + result[i].lesson_number + '</td>' +
	  			'<td>' + result[i].auditorium + '</td>' +
	  			'<td>' + result[i].disciple + '</td>'+
	  			'<td><ul>';
  			for (var j = 0; j < result[i].teacher.length; j++) {
  				output += '<li>' + result[i].teacher[j] + '</li>';
  			}
	  		output +='</ul></td></tr>';
	  	}
	  	$('#result1 tbody').html(output);
	} else {
		alert("В Local Storage нет таких данных!");
	}
}

function getLocal2(e) {
	$('#result2 tbody').html('');
	var currentForm = $(e).parents('form');
	var result = JSON.parse(localStorage.getItem('form2Result'));
	var data = localStorage.getItem('form2Data');
	if (currentForm.serialize() === data) {
	  	var output = "";

	  	for (var i = 0; i < result.length; i++) {
	  		output += '<tr>'+
	  			'<td>' + result[i].date + '</td>' +
	  			'<td>' + result[i].lesson_number + '</td>' +
	  			'<td>' + result[i].auditorium + '</td>' +
	  			'<td>' + result[i].disciple + '</td>'+
	  			'<td><ul>';
  			for (var j = 0; j < result[i].groups.length; j++) {
  				output += '<li>' + result[i].groups[j] + '</li>';
  			}
	  		output +='</ul></td></tr>';
	  	}
	  	$('#result2 tbody').html(output);
	} else {
		alert("В Local Storage нет таких данных!");
	}
}

function getLocal3(e) {
	$('#result3 tbody').html('');
	var currentForm = $(e).parents('form');
	var result = JSON.parse(localStorage.getItem('form3Result'));
	var data = localStorage.getItem('form3Data');
	if (currentForm.serialize() === data) {
	  	var output = "";
	  	
	  	for (var i = 0; i < result.length; i++) {
	  		output += '<tr>'+
	  			'<td>' + result[i].date + '</td>' +
	  			'<td>' + result[i].lesson_number + '</td>' +
	  			'<td>' + result[i].auditorium + '</td>' +
	  			'<td>' + result[i].disciple + '</td>'+
	  			'<td>' + result[i].type + '</td>'+
	  			'<td><ul>';
  			for (var j = 0; j < result[i].groups.length; j++) {
  				output += '<li>' + result[i].groups[j] + '</li>';
  			}
  			output += '</ul></td><td><ul>';
  			for (var j = 0; j < result[i].teacher.length; j++) {
  				output += '<li>' + result[i].teacher[j] + '</li>';
  			}
	  		output +='</ul></td></tr>';
	  	}
	  	$('#result3 tbody').html(output);
	} else {
		alert("В Local Storage нет таких данных!");
	}
}