<?php

$cursor = $db->lessons->distinct('groups');
$groups = $cursor;
