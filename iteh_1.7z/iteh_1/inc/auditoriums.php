<?php

$cursor = $db->lessons->distinct('auditorium');
$auditoriums = $cursor;
