<?php

$cursor = $db->lessons->distinct('teacher');
$teachers = $cursor;

